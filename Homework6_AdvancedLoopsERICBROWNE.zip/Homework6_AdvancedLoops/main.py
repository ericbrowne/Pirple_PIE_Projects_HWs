## Eric Browne
## Pirple: Python is Easy
## Homework6: Advanced Loops


def createBoard(rows,columns):
    """
    Creates game board with amount of columns and rows
    specified by the inputs of rows,cols.
    """
    #   For our function, the actual number of rows and columns of the game
    # board will be rows,cols; but the computer will need to print out
    # rows*2-1 rows and cols*2-1 columns.

    ### Even row =
    ###     Even col = "-"
    ###     Odd col = "-"
    ### Odd row =
    ###     Even col = "|"
    ###     Odd col = "  "


    assert type(rows) is int
    assert type(columns) is int

    # If its greater than the max dimensions:  (Extra Credit)
    if rows>14 or columns>99:
        return False
    else:

        for row in range(1,rows*2-1+1):
            if row%2==1:  # if the row number is odd
                for col in range(1,columns*2-1+1):
                    if col%2==1:  # odd col
                        if col==(columns*2 - 1):
                            print(" ") # the final col
                        else:
                            print(" ",end="") # normal odd col
                    else:  # Even col
                        print("|",end="")
            else:  # even row
                print("-"*(columns*2-1))

        return True

# Max number of rows by columns is 14X99 to comfortably fit on screen
# By 'comforably fit on screen', I mean you can see the command+output, as well as have
# no text wrapping.
## I am also using my windows command line at full screen
print(createBoard(14,99)) # prints board with a True returned
print(createBoard(1000000,1000000)) # Returns False
