## Eric Browne
## Pirple: Python is Easy
## Homework 3: If Statements



## make a function to compare 3 parameters
def comparison(param1,param2,param3):
    count = 0

    # converts ints to strings, and strings to begin with stay the same
    # This way, we cover both cases
    # It is more efficient code to do str() instead of int()
    ##      This is because every int can be a str, but not every str can be an int
    param1 = str(param1)
    param2 = str(param2)
    param3 = str(param3)


    # There is currently 3 choose 2 combinations = 3
    if param1==param2:
        count+=1
    if param1==param3:
        count+=1
    if param2==param3:
        count+=1
    if count >= 1:  # if there is atleast 2 parameters that are the same
        return True
    else:
        return False

## Print statements: True
print('\n3 Trues:')
print(comparison(5,5,6))
print(comparison(7,7,10))
print(comparison('string','string',3))

## Print Statements: False
print('\n3 Falses:')
print(comparison(18,1,9))
print(comparison('stronnng','string','foo'))
print(comparison('foo',6,'8'))

## Print Statements Extra Credit:
print('\nExtra Credit:  2 Trues')
print(comparison(6,6,'5')) #Should be True
print(comparison('12',469,'469')) # Should be True
