## Eric Browne
## Pirple: Python is Easy
## Homework 2: Functions
"""
The premise of this script is to build on the previous homework of "Your Favorite Song".
Each attribute/feature of the song will now be in the form of a function, and when called, will return the corresponding value with a messaage!
"""


### Set values for each of the three attributes of the song:
song_name = 'Blackened'
era = 'Thrash Metal 80s'
album = 'And Justice For All..'



### Create three new functions:
def Era():
    return era

def Song_Name():
    return song_name

def Album():
    return album


### Print out the return values of the function
print(Era())
print(Song_Name())
print(Album())



### Extra Credit: Boolean Functions

bestSongEver = True
def BooleanFunc():
    return bestSongEver

print(BooleanFunc())
