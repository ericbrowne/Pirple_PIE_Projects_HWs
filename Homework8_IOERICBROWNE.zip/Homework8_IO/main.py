## Eric Browne
## Pirple: Python is Easy
## Homework 8: I/O


## Imported Libraries:
import os
from os import path





## prompt user for file name


## Initialize a stoppin condition
bool=True
while bool==True:
    filename = input("Enter a File Name: ")
## If file already exists in directory:
    if path.exists(filename):
        print("This file already exists!")
        ## Ask user what they want to do:
        user_input = input("Read, Delete, Append or Replace file?: (Case Sensitive)  ")
        if user_input=="Read":
            print("\n")
            with open(filename, "r") as File:
                for line in File:
                    print(line, end="")
            print("\n")
            input_continue=input("Make another operation? (Yes or No, Case Sensitive): ")
            if input_continue=="Yes":
                continue
            elif input_continue=="No":

                ## Exit loop
                bool=False
            else:
                print("Sorry that was not a correct input.  Killing program now!")

                ## Exit loop
                bool=False



        elif user_input=="Delete":
            os.remove(filename)
            new_file = input("Please input a new file to be constructed: ")
            with open(new_file,"w") as File:
                File.close()
            print("\n")
            input_continue=input("Make another operation? (Yes or No, Case Sensitive): ")
            if input_continue=="Yes":
                continue
            elif input_continue=="No":
                bool=False
            else:
                print("\nSorry that was not a correct input.  Killing program now!")
                bool=False




        elif user_input=="Append":
            inputt = input("What to Append: ")
            with open(filename,"a") as File:
                File.write(f"\n{inputt}")
            print("\n")
            input_continue=input("Make another operation? (Yes or No, Case Sensitive): ")
            if input_continue=="Yes":
                continue
            elif input_continue=="No":
                bool=False
            else:
                print("Sorry that was not a correct input.  Killing program now!")
                bool=False




        ### EXTRA CREDIT ###
        elif user_input=="Replace":
            ## Account for actual line # vs computer line #
            line = int(input("Which Line to update?: "))-1
            updated_text = input("Write: ")
            with open(filename, "r+") as File:
                lines = File.readlines()
                lines[line]=f"{updated_text}\n"
                File.writelines(lines)
            print("\n")
            input_continue=input("Make another operation? (Yes or No, Case Sensitive): ")
            if input_continue=="Yes":
                continue
            elif input_continue=="No":
                bool=False
            else:
                print("\nSorry that was not a correct input.  Killing program now!")
                bool=False
        else:
            print("\nSorry that was not a correct Input!  Killing Program now!")
            bool=False


        ## If the file doesnt exist:
    else:
        print("This file doesnt exist yet.  Lets create it.")
        with open(filename, "w") as File:
            what_to_write = input("Write:  ")
            File.write(what_to_write)
        input_continue=input("Make another operation? (Yes or No, Case Sensitive): ")
        if input_continue=="Yes":
            continue
        elif input_continue=="No":
            bool=False
        else:
            print("\nSorry that was not a correct input.  Killing program now!")
            bool=False
