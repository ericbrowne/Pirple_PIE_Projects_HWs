## Eric Browne
## Pirple: Python is Easy
## Homework4: Lists

# Create global Variables:
myUniqueList = []
myLeftovers = []

def foo(x):
    """ Adds element to list: myUniqueList, unless its already a part of the list.
    In which case it adds it to another list: myLeftovers"""
    myUniqueList2 = set(myUniqueList)
    if x in myUniqueList2:
        myLeftovers.append(x)
        return False
    else:
        myUniqueList.append(x)
    return True


print('List is Empty:', myUniqueList)
print(foo(1)) # True
print(foo(1)) # False
print(foo(2)) # True
print(foo('list element')) # True
print(foo('list element')) # False


# Make sure it works for a sanity check:
print('myUniqueList',myUniqueList) # Should print: [1,2,'list element']
print('myLeftovers',myLeftovers) # should print: [1, 'list element']
