## Eric Browne
## Pirple: Python is Easy
## Homework 1: Variables


"""
Title: My FAvorite Song!

In this python script, I will dictate some attributes of my favorite song of all time:  Blackened, Metallica

"""







### Assign the Variables:
genre = 'Metal'  # assign the 'genre' variable to be a strinf: 'metal'
artist = 'Metallica' # assign the artist variable to be a string: 'metallica'
duration_seconds = 402
duration_minutes = duration_seconds/60 # we use a single slash to not floor the variable (we want a float)
song_name = 'Blackened'
era = 'Thrash Metal 80s'
album = 'And Justice For All..'
sickasfrick_riffs = 69.420
babies = "Too many to count"




### Print out the variables:
print(" Listed below are some attributes describing my favorite song!\n")
print("Genre:", genre)
print("Artist:", artist)
print("# of seconds in the song:", duration_seconds)
print( "# of minutes in the song:", duration_minutes)
print("Name:", song_name)
print("Popular Era of the song:", era)
print('Album:', album)
print("# of face melting riffs:" ,sickasfrick_riffs, "!!!!!!")
print(" Amount of babies conceived to this song:", babies)
