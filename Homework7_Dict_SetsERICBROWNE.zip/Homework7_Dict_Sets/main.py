## Eric Browne
## Pirple: Python is Easy
## Homework 7: Dictionaries, Sets



def songDict(input = False):
    """Function creates a dictionary with song attributes, and
    then prints out the key,value pairs.
    """
    song_dict = {"genre":"Metal",
                        "artist":"Metallica",
                        "duration_seconds":402,
                        "duration_minutes":(402/60),
                        "song_name":"Blackened",
                        "era":"Thrash Metal 80s",
                        "Album":"And Justice for All...",
                        "sickasfrick_riffs":69.420,
                        "babies":"Too many to count"}

    # Now for every key and value, print them out

    if input:
        for key in song_dict:
            print(key,":", song_dict[key])

    # returns the actual dicionary to be used in the next function
    return song_dict

## All this will do is print the key,value pairs in song_dictionary
songDict(input=True)

## Extra Credit
def guess(key, value):
    """ Function checks to see if a given key and value is in a
    specific dictionary.  Returns True if it is, False otherwise"""

    dict = songDict() # dict is now the same as song_dict
    if key in dict: # is the key in the dictionary?
        if dict[key]==value: # is the value the correct one?
            print(key,":",dict[key])
            return True # correct key and value
        else:
            return False # correct key, but not value
    else:
        return False # incorrect key


print("\n")
# Correct Key, but not correct value:
print(guess('genre','Techno'))  # should return False

#Correct key and correcy value
print(guess('artist','Metallica')) # should return True

# Incorrect key
print(guess('incorrect',80)) # should return False
