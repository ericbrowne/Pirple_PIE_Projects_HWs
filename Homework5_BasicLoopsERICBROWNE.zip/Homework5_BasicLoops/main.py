## Eric Browne
## PirpleL: Python is Easy
## Homework5: Basic Loops, FIZZBUZZ


# Helper Function
def isPrime(number):
    """Checks it number is a prime number
        If Prime: returns True
        If not Prime: returns False
    """

    if number <=1:
        return False
    if number > 1 :
        if number <= 3:
            return True
    if number%2 == 0 or number%3 == 0:
        return False

    iter = 5
    while iter*iter <= number:
        if number%iter == 0 or number%(iter+2) == 0:
            return False
        iter = iter + 6
    return True





def fizzbuzz():
    """ Prints numbers from 1-100
        If the number is a multiple of 3: print 'Fizz'
        If the number is a multiple of 5: print 'Buzz'
        If the number is a multiple of 3 and 5: print 'Fizzbuzz'
        If the number is prime: print 'Prime'
    """
    for i in range(1,101):
        if isPrime(i):  # if it is a prime number, change that string to 'Prime'
            str='PRIME'
        else:
            if i%3==0 and i%5==0:
                str='FizzBuzz' # Change string to Fizzbuzz
            elif i%3==0:
                str= 'Fizz' # Change string to Fizz
            elif i%5==0:
                str='Buzz' # Change string to Buzz
            else:
                str=f"{i}" # If it meets none of the above conditions
        print(str)


fizzbuzz()
